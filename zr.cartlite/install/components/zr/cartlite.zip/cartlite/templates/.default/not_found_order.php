<table class="sale_order_full_table">
    <tbody style="margin: 0 auto;">
        <tr>
            <td>
                Заказ <b>№<?=$_REQUEST['ORDER_ID']?></b> не найден.
                <br>
                <br>
                <b>Пожалуйста обратитесь к администрации интернет-магазина или попробуйте оформить ваш заказ еще раз.</b>
                <br>
                <br>
            </td>
        </tr>
    </tbody>
</table>