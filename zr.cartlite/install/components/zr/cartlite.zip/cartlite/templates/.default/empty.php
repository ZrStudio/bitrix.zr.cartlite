<div class="bx-sbb-empty-cart-container">
	<div class="bx-sbb-empty-cart-image">
		<img data-lazyload="" class=" lazyloaded" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="" alt="">
	</div>
	<div class="bx-sbb-empty-cart-text">
        Ваша корзина пуста
    </div>
    <div class="bx-sbb-empty-cart-desc">
        <a href="<?=$arParams['BACK_CATALOG_URL']?>">Нажмите здесь</a>, чтобы продолжить покупки
    </div>
</div>