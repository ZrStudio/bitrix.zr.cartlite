<table class="sale_order_full_table">
    <tbody style="margin: 0 auto;">
        <tr>
            <td>
                Ваш заказ <b>№<?=$orderId?></b> от 21.08.2023 12:02 успешно создан.
                <br><br>
                <b>Ожидайте, с вами свяжется менеждеж для уточнение деталей.</b><br><br> 
            </td>
        </tr>
    </tbody>
</table>