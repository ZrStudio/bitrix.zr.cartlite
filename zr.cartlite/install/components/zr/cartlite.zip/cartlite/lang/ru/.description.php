<?
    $MESS['COMPONENT_NAME'] = "Корзина";
    $MESS['COMPONENT_DESCRIPTION'] = "Компонент выводит корзину товаров";
    $MESS['COMPONENT_CHILD_NAME'] = "Корзина LITE";
?>