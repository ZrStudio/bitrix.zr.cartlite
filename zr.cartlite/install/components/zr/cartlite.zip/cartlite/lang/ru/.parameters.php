<?
	$MESS["ZR_CL_BACK_URL"] = "Ссылка на страницу после оформления";
    $MESS["ZR_CL_BACK_CATALOG_URL"] = "Ссылка на каталог";

    $MESS["ZR_CL_TYPE_SHOW_TOTAL_CONTAINER"] = "Формат вывода итоговой цены";
    $MESS["ZR_CL_TYPE_SHOW_TOTAL_CONTAINER_TOP"] = "Сверху таблицы товаров";
    $MESS["ZR_CL_TYPE_SHOW_TOTAL_CONTAINER_BOTTOM"] = "Снизу таблицы товаров";
?>